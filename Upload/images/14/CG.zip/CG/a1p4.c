//assg 1 set b 2
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<GL/gl.h>
#include<GL/glu.h>
#include<GL/glut.h>

void myinit()
{
 glClearColor(1.0,1.0,1.0,0.0);
 glColor3f(0.0f,0.0f,0.0f);
 glPointSize(4.0);
 glMatrixMode(GL_PROJECTION);
 glLoadIdentity();
 gluOrtho2D(0.0,640.0,0.0,480.0);
}

void myDisplay(void)
{
 int i;
 glClear(GL_COLOR_BUFFER_BIT);
 glBegin(GL_LINES);
 glVertex2i(10,20);
 glVertex2i(50,140);
 //glVertex2i(50,140);
 glVertex2i(80,20);
 glVertex2i(10,100);
 glVertex2i(10,100);
 glVertex2i(80,100);
 glVertex2i(80,100);
 glVertex2i(10,20);
 glVertex2i(10,20);
 glVertex2i(50,140);
 glVertex2i(50,100);
 glEnd();
 glFlush();
}

int main(int argc,char **argv)
{
 glutInit(&argc,argv);
 glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
 glutInitWindowSize(640,480);
 glutCreateWindow("Assignment1prog3");
 glutDisplayFunc(myDisplay);
 myinit();
 glutMainLoop();
 return 0;
}
