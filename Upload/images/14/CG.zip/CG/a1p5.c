//assg 1 set b 3
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<GL/gl.h>
#include<GL/glu.h>
#include<GL/glut.h>

void myinit()
{
 glClearColor(1.0,1.0,1.0,0.0);
 glColor3f(0.0f,0.0f,0.0f);
 glPointSize(4.0);
 glMatrixMode(GL_PROJECTION);
 glLoadIdentity();
 gluOrtho2D(0.0,640.0,0.0,480.0);
}

void myDisplay(void)
{
 int i,j,x1,x2,y1,y2;
 glClear(GL_COLOR_BUFFER_BIT);
 x1=0;x2=0;y1=60;y2=45;
 for(i=0;i<8;i++)
 {
  y1=i*y2;
 for(j=0;j<8;j++)
 {
 x1=j*x2;
 if((i+j)%2==0)
  glColor3f(0.3,0.3,0.3);
 else
 {
  glColor3f(0.0,0.0,0.0);
  glBegin(GL_QUADS);
  glVertex2i(x1,y1);
  glVertex2i(x1+x2,y1);
  glVertex2i(x1+x2,y1+y2);
  glVertex2i(x1,y1+y2);
  
  glEnd();
 }
 }
}
  glFlush();
}

int main(int argc,char **argv)
{
 glutInit(&argc,argv);
 glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
 glutInitWindowSize(640,480);
 glutInitWindowPosition(350,350);
 glutCreateWindow("Assignment1prog5");
 glutDisplayFunc(myDisplay);
 myinit();
 glutMainLoop();
}
