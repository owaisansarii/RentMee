//assg 1 set a 3
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<GL/gl.h>
#include<GL/glu.h>
#include<GL/glut.h>

void myinit(void)
{
 glClearColor(1.0,1.0,1.0,0.0);
 glColor3f(0.0f,0.0f,0.0f);
 glPointSize(4.0);
 glMatrixMode(GL_PROJECTION);
 glLoadIdentity();
 gluOrtho2D(0.0,640.0,0.0,480.0);
}

void myDisplay(void)
{
 int i;
 GLint x,y,r,g,b;
 glClear(GL_COLOR_BUFFER_BIT);
 glColor3f(0.0f,0.0f,0.0f);
 glBegin(GL_POINTS);
 for(i=0;i<50;i++)
 {
  x=rand()%630;
  y=rand()%470;
  r=rand()%2;
  g=rand()%2;
  b=rand()%2;
  glColor3f(r,g,b);
  glVertex2i(x,y);
 }
  glEnd();
  glFlush();
}

int main(int argc,char **argv)
{
 glutInit(&argc,argv);
 glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
 glutInitWindowSize(640,480);
 glutInitWindowPosition(350,350);
 glutCreateWindow("Assignment1prog2");
 glutDisplayFunc(myDisplay);
 myinit();
 glutMainLoop();
 return 0;
}
