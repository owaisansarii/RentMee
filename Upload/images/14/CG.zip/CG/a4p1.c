//assg 4 set a 1
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<GL/gl.h>
#include<GL/glu.h>
#include<GL/glut.h>

typedef struct
{
GLint x,y;
}GLintPoint;

GLintPoint p1;
 
void myinit(void)
{
 glClearColor(1.0,1.0,1.0,0.0);
 glColor3f(0.0f,0.0f,0.0f);
 glPointSize(4.0);
 glMatrixMode(GL_PROJECTION);
 glLoadIdentity();
 gluOrtho2D(0.0,640.0,0.0,480.0);
}

void myMouse(int button,int state,int x,int y)
{ 

 if(state==GLUT_DOWN && button==GLUT_LEFT_BUTTON)
 {
 p1.x=x;
 p1.y=y;
 }
 glutPostRedisplay();
 glFlush();
}

void display()
{
  glBegin(GL_POINTS);
 glColor3f(1.0,0.2,0.2);
 glVertex2i(p1.x,p1.y);
 glEnd();
 glFlush();
}

int main(int argc,char **argv)
{
 glutInit(&argc,argv);
 glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
 glutInitWindowSize(640,480);
 glutCreateWindow("Assignment3prog1");
 glutMouseFunc(myMouse);
 glutDisplayFunc(display);
 myinit();
 glutMainLoop();
 return 0;
}
