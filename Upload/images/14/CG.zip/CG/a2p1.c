//assg 2 set a 1
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<GL/gl.h>
#include<GL/glu.h>
#include<GL/glut.h>

void myinit(void)
{
 glClearColor(1.0,1.0,1.0,0.0);
 glMatrixMode(GL_PROJECTION);
 gluOrtho2D(0.0,640.0,0.0,480.0);
}


void setPixel(GLint x,GLint y)
{
glBegin(GL_POINTS);
glVertex2i(x,y);
glEnd();
glFlush();
}


void lineBres(GLint x0,GLint y0,GLint xend,GLint yend)
{
GLint dx=fabs(xend-0);
GLint dy=fabs(yend-0);
GLint p=2*dy-dx;
GLint twody=2*dy;
GLint dydx=2*(dy-dx);
GLint x,y;
if(x0>xend)
{
 x=xend;
 y=yend;
 xend=x;
}
else
{
 x=x0;
 y=y0;
}

setPixel(x,y);
while(x<xend)
{
x++;
if(p<0)
{
p+=twody;
}
else
{
y++;
p+=dydx;
}
setPixel(x,y);
}
}

void drawLine(void)
{
 glClear(GL_COLOR_BUFFER_BIT);
 glColor3f(1.0,0.0,0.0);
 glPointSize(4.0);
 GLint x0=100;
 GLint y0=150;
 GLint xend=200;
 GLint yend=200;
 lineBres(x0,y0,xend,yend);
}

int main(int argc,char **argv)
{
 glutInit(&argc,argv);
 glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
 glutInitWindowSize(640,480);
 glutCreateWindow("Assignment2prog1");
 glutDisplayFunc(drawLine);
 myinit();
 glutMainLoop();
 return 0;
}
